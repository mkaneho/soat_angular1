export function clone(item) {
  return JSON.parse(JSON.stringify(item))
}
