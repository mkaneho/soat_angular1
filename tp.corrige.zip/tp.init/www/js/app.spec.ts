describe('App', () => {

  let $state
  let $location
  let $rootScope
  let $ngRedux

  beforeEach(angular.mock.module('ToyStore'))

  beforeEach(angular.mock.inject((_$rootScope_, _$ngRedux_, _$state_, _$location_) => {
    $rootScope = _$rootScope_
    $state = _$state_
    $ngRedux = _$ngRedux_
    $location = _$location_

    spyOn($ngRedux, 'dispatch').and.returnValue('ok')
  }))

  it('Should redirect to toys', () => {
    $location.url('/')
    $rootScope.$apply()
    expect($state.current.name).toBe('toys')
  })

  it('Should go to toys', () => {
    $location.url('/toys')
    $rootScope.$apply()
    expect($state.current.name).toBe('toys')
  })

  it('Should go to basket', () => {
    $location.url('/basket')
    $rootScope.$apply()
    expect($state.current.name).toBe('basket')
  })

  it('Should go to checkout', () => {
    $location.url('/checkout')
    $rootScope.$apply()
    expect($state.current.name).toBe('checkout')
  })
})
