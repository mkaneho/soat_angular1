import ngRedux from 'ng-redux'

/*
 *  App Modules
 */
import actions from './actions/actions.module'
import components from './components/components.module'
import Config from './config'
import containers from './containers/containers.module'
import services from './services/services.module'

angular.module('ToyStore', [
  'ui.router',
  actions.name,
  components.name,
  containers.name,
  services.name,
  ngRedux
])
.config(Config)

angular.bootstrap(document.documentElement, ['ToyStore'])
