import 'ng-cache!./toy.component.html'

export default class ToyComponent {
  public bindings
  public templateUrl
  constructor() {
    this.bindings = {
      toy: '<',
      onSelect: '&'
    }
    this.templateUrl = 'toy.component.html'
  }
}
