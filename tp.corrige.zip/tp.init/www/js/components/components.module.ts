
import ToyComponent from './toy.component'

export default angular.module('components.module', [])
  .component('toyComponent', new ToyComponent())
