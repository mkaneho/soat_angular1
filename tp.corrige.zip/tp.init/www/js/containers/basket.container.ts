import 'ng-cache!./basket.html'

class BasketController {
  public toys
  public price
  private disconnect

  constructor(
    private $ngRedux,
    private $state,
    private toyActions
  ) {}

  $onInit = () => {
    this.disconnect = this.$ngRedux.connect(this.mapStateToThis, () => {})(this)
  }

  $onDestroy = () => {
    this.disconnect()
  }

  delete = obj => {
    this.$ngRedux.dispatch(this.toyActions.selectToy(obj))
  }

  checkout = () => {
    this.$state.go('checkout')
  }

  private mapStateToThis(state) {
    return {
      toys: state.toyReducer.toys.filter(item => {
        return item.selected
      }),
      price: state.toyReducer.price
    }
  }
}

class BasketContainer {
  public controller
  public templateUrl
  constructor() {
    this.controller = BasketController
    this.templateUrl = 'basket.html'
  }
}

BasketController.$inject = ['$ngRedux', '$state', 'ToyActions']
export default BasketContainer
