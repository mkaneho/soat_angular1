import 'ng-cache!./checkout.html'

class CheckoutController {
  public payed
  public user
  public price
  private disconnect

  constructor(
    private $ngRedux,
    private userActions
  ) {}

  $onInit = () => {
    this.disconnect = this.$ngRedux.connect(this.mapStateToThis, () => {})(this)
  }

  $onDestroy = () => {
    this.disconnect()
  }

  payIt() {
    this.$ngRedux.dispatch(this.userActions.pay())
  }

  private mapStateToThis(state) {
    return {
      user: state.userReducer,
      price: state.toyReducer.price
    }
  }
}

class CheckoutContainer {
  public controller
  public templateUrl
  constructor() {
    this.controller = CheckoutController
    this.templateUrl = 'checkout.html'
  }
}

CheckoutController.$inject = ['$ngRedux', 'UserActions']
export default CheckoutContainer
