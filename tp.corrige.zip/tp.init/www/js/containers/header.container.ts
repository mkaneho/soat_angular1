import 'ng-cache!./header.html'

class HeaderController {
  public counter
  private disconnect

  constructor(
    private $ngRedux
  ) {}

  $onInit = () => {
    this.disconnect = this.$ngRedux.connect(this.mapStateToThis, () => {})(this)
  }

  $onDestroy = () => {
    this.disconnect()
  }

  private mapStateToThis(state) {
    return {
      counter: state.toyReducer.counter
    }
  }
}

class HeaderContainer {
  public controller
  public templateUrl
  constructor() {
    this.controller = HeaderController
    this.templateUrl = 'header.html'
  }
}

HeaderController.$inject = ['$ngRedux']
export default HeaderContainer
