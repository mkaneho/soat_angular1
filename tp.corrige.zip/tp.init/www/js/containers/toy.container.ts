import 'ng-cache!./toy.html'

class ToyController {

  public toys
  private disconnect

  constructor(
    private $ngRedux,
    private toyActions
  ) {}

  $onInit = () => {
    this.disconnect = this.$ngRedux.connect(this.mapStateToThis, () => {})(this)
    this.$ngRedux.dispatch( this.toyActions.getToys() )
  }

  $onDestroy = () => {
    this.disconnect()
  }

  onSelect = obj => {
    this.$ngRedux.dispatch( this.toyActions.selectToy(obj) )
  }

  private mapStateToThis(state) {
    return {
      toys: state.toyReducer.toys
    }
  }
}

class ToyContainer {
  public controller
  public templateUrl
  constructor() {
    this.controller = ToyController
    this.templateUrl = 'toy.html'
  }
}

ToyController.$inject = ['$ngRedux', 'ToyActions']
export default ToyContainer
