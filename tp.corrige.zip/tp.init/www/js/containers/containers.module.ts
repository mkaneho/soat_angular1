import BasketContainer from './basket.container'
import CheckoutContainer from './checkout.container'
import HeaderContainer from './header.container'
import MainContainer from './main.container'
import ToyContainer from './toy.container'

export default angular.module('containers.module', [])
  .component('basketContainer', new BasketContainer())
  .component('checkoutContainer', new CheckoutContainer())
  .component('headerContainer', new HeaderContainer())
  .component('mainContainer', new MainContainer())
  .component('toyContainer', new ToyContainer())
