class MainContainer {
  public template
  constructor() {
    this.template = `
      <header-container></header-container>
      <div ui-view></div>
    `
  }
}

export default MainContainer
