import { USER } from '../actions/user.actions'
import userReducer from './user.reducer'

describe('User Reducer', () => {

  let result
  const initState = {}

  it('Should pass', () => {
    result = userReducer(initState, {
      type: 'OTHER'
    })
    expect(result).toEqual(initState)
  })

  it('Should pay', () => {
    result = userReducer(initState, {
      type: USER.PAY
    })
    expect(result.payed).toBe(true)
  })

})
