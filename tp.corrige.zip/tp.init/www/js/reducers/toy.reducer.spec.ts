import { TOY } from '../actions/toy.actions'
import toyReducer from './toy.reducer'

describe('Toy Reducer', () => {

  let result
  const initState = {
    toys: [],
    price: 0,
    counter: 0
  }

  it('Should pass', () => {
    result = toyReducer(initState, {
      type: 'OTHER'
    })
    expect(result).toEqual(initState)
  })

  it('Should request toys', () => {
    result = toyReducer(initState, {
      type: TOY.REQUEST
    })
    expect(result).toEqual(initState)
  })

  it('Should get toys', () => {
    result = toyReducer(initState, {
      type: TOY.RESPONSE,
      toys: 'toy list'
    })
    expect(result.toys).toEqual('toy list')
  })

  it('Should select a toy', () => {
    initState.toys = [
      {
        title: 'hello'
      }
    ]
    result = toyReducer(initState, {
      type: TOY.SELECT,
      toy: {
        title: 'hello'
      }
    })
    expect(result.counter).toBe(1)
  })

  it('Should deselect a toy', () => {
    initState.toys = [
      {
        title: 'hello',
        selected: true
      }
    ]
    result = toyReducer(initState, {
      type: TOY.SELECT,
      toy: {
        title: 'hello'
      }
    })
    expect(result.counter).toBe(0)
  })

  it('Should compute the price', () => {
    initState.toys = [
      {
        selected: true,
        price: 10
      },
      {
        selected: true,
        price: 20
      },
      {
        price: 50
      }
    ]
    result = toyReducer(initState, {
      type: TOY.COMPUTE
    })
    expect(result.price).toBe(30)
  })
})
