import ToyService from './toy.service'

export default angular.module('services.module', [])
  .service('ToyService', ToyService)

