import { TOY } from './toy.actions'

describe('Toy Actions', () => {

  let $q, $rootScope, scope, redux, toyActions, toyService, result

  beforeEach(angular.mock.module('ToyStore'))

  beforeEach(angular.mock.inject((_$q_, _$rootScope_, _ToyActions_, _ToyService_) => {
    $q = _$q_
    $rootScope = _$rootScope_
    scope = $rootScope.$new()
    toyActions = _ToyActions_
    toyService = _ToyService_

    redux = {
      dispatch: () => {},
      getState: () => {}
    }

    spyOn(toyService, 'getToys').and.callFake(() => {
      const defer = $q.defer()
      defer.resolve('result')
      return defer.promise
    })
    spyOn(redux, 'dispatch')

  }))

  it('Should get toys', () => {
    spyOn(redux, 'getState').and.returnValue({
      toyReducer: {
        toys: []
      }
    })

    result = toyActions.getToys()
    result(redux.dispatch, redux.getState)

    expect(redux.getState).toHaveBeenCalled()
    expect(redux.dispatch).toHaveBeenCalledWith({
      type: TOY.REQUEST
    })
    expect(toyService.getToys).toHaveBeenCalled()

    scope.$apply()
    expect(redux.dispatch).toHaveBeenCalledWith({
      type: TOY.RESPONSE,
      toys: 'result'
    })
  })

  it('Should do nothing', () => {
    spyOn(redux, 'getState').and.returnValue({
      toyReducer: {
        toys: [1]
      }
    })

    result = toyActions.getToys()
    result(redux.dispatch, redux.getState)

    expect(redux.getState).toHaveBeenCalled()
    expect(redux.dispatch).not.toHaveBeenCalled()
  })

  it('Should select a toy', () => {
    result = toyActions.selectToy('toto')
    result(redux.dispatch, redux.getState)

    expect(redux.dispatch).toHaveBeenCalledWith({
      type: TOY.SELECT,
      toy: 'toto'
    })
    expect(redux.dispatch).toHaveBeenCalledWith({
      type: TOY.COMPUTE
    })
  })

})
