import { USER } from './user.actions'

describe('User Actions', () => {

  let userActions

  beforeEach(angular.mock.module('ToyStore'))

  beforeEach(angular.mock.inject((_UserActions_) => {
    userActions = _UserActions_
  }))

  it('Should pay', () => {
    const result = userActions.pay()
    expect(result).toEqual({
      type: USER.PAY
    })
  })

})
