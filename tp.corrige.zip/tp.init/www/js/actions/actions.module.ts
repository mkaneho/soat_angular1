import ToyActions from './toy.actions'
import UserActions from './user.actions'

export default angular.module('actions.module', [])
  .service('ToyActions', ToyActions)
  .service('UserActions', UserActions)
