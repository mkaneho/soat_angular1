export const USER = {
  PAY: 'USER_PAY'
}

export default class UserActions {

  constructor() {}

  pay = () => {
    return {
      type: USER.PAY
    }
  }
}
